﻿namespace AssesmentApi.Models
{
    public class CombinedResult
    {
        public People Swapi { get; set; }
        public Jokes Chuck { get; set; }
    }
}
